(function () {
  'use strict';

  /* =====================================================
     CONFIGURAÇÕES — EDITE AQUI
     ===================================================== */
  var CONFIG = {
    // Frases sorteadas a cada tentativa de clicar em "Não"
    phrases: [
      'Uai, tá com medo de quê? KKKKK 😂',
      'O convite tá feito, falta você aceitar. 👀',
      'Para de fugir e vem assistir comigo! 🤭',
      'Esse botão não vai te salvar, não. KKKKK 😈',
      'Você sabe muito bem qual opção escolher. ❤️‍🔥',
      'Olha que eu vou considerar isso um desafio! 😂',
      'Não adianta correr, o convite continua de pé. 💋'
    ],

    // Botão "Agora combina comigo 😏"
    // Coloque seu número com país + DDD, só números. Ex.: '5531999999999'
    // Se deixar vazio, aparece só o aviso abaixo.
    whatsappNumber: '',
    whatsappMessage: 'Aceitei o convite 😏 Bora combinar o dia?',
    noNumberNote: 'Me chama no WhatsApp e a gente combina! 😏',

    // Corações de fundo
    heartsCount: 16,
    heartEmojis: ['❤️', '💗', '💖', '💕', '🩷'],

    // Cores dos confetes
    confettiColors: ['#ff5c8a', '#e11d48', '#b3123b', '#6d0f2b', '#ffb9cb', '#ffffff', '#ffd166']
  };
  /* ===================================================== */

  var $ = function (id) { return document.getElementById(id); };
  var yesBtn = $('btn-yes');
  var noBtn = $('btn-no');
  var buttons = $('buttons');
  var copy = $('copy');
  var toast = $('toast');
  var question = $('question');
  var success = $('success');
  var planBtn = $('btn-plan');
  var planNote = $('plan-note');
  var canvas = $('confetti');

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var fled = false;
  var accepted = false;
  var lastFlee = 0;
  var lastPhrase = -1;
  var yesScale = 1;
  var noPos = { x: 0, y: 0 };
  var pointer = { x: -9999, y: -9999, known: false };
  var toastTimer = null;
  var slot = null;

  function rand(min, max) { return min + Math.random() * (max - min); }

  /* ---------- Corações de fundo ---------- */
  (function createHearts() {
    var wrap = $('hearts');
    var frag = document.createDocumentFragment();
    for (var i = 0; i < CONFIG.heartsCount; i++) {
      var h = document.createElement('span');
      h.className = 'heart';
      h.textContent = CONFIG.heartEmojis[Math.floor(Math.random() * CONFIG.heartEmojis.length)];
      h.style.left = rand(0, 96).toFixed(1) + '%';
      h.style.fontSize = rand(14, 34).toFixed(0) + 'px';
      h.style.animationDuration = rand(10, 20).toFixed(1) + 's';
      h.style.animationDelay = '-' + rand(0, 20).toFixed(1) + 's';
      h.style.setProperty('--drift', rand(-60, 60).toFixed(0) + 'px');
      h.style.setProperty('--rot', rand(-35, 35).toFixed(0) + 'deg');
      h.style.setProperty('--o', rand(0.25, 0.55).toFixed(2));
      frag.appendChild(h);
    }
    wrap.appendChild(frag);
  })();

  /* ---------- Frases ---------- */
  function showPhrase() {
    var list = CONFIG.phrases;
    var idx = Math.floor(Math.random() * list.length);
    if (list.length > 1 && idx === lastPhrase) idx = (idx + 1) % list.length;
    lastPhrase = idx;

    toast.textContent = list[idx];
    toast.classList.remove('show');
    void toast.offsetWidth; // reinicia a animação
    toast.classList.add('show');

    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 2600);
  }

  /* ---------- Botão "Não" fujão ---------- */
  function rectsOverlap(a, b) {
    return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  }

  function inflate(r, p) {
    return { left: r.left - p, top: r.top - p, right: r.right + p, bottom: r.bottom + p };
  }

  // Área que o botão "Sim" vai ocupar (já considerando que ele cresce um pouco)
  function yesFutureRect() {
    var r = yesBtn.getBoundingClientRect();
    var cx = r.left + r.width / 2;
    var cy = r.top + r.height / 2;
    var w = yesBtn.offsetWidth * yesScale;
    var h = yesBtn.offsetHeight * yesScale;
    return inflate({ left: cx - w / 2, top: cy - h / 2, right: cx + w / 2, bottom: cy + h / 2 }, 22);
  }

  function getBounds(w, h) {
    var vw = document.documentElement.clientWidth || window.innerWidth;
    var vh = window.innerHeight;
    var m = 12;
    var minX = m, minY = m;
    var maxX = Math.max(minX, vw - w - m);
    var maxY = Math.max(minY, vh - h - 90); // deixa espaço para a frase embaixo
    return { minX: minX, maxX: maxX, minY: minY, maxY: maxY };
  }

  function findSpot(w, h, obstacles, avoidPointer) {
    var b = getBounds(w, h);
    for (var i = 0; i < 40; i++) {
      var x = rand(b.minX, b.maxX);
      var y = rand(b.minY, b.maxY);
      var rect = { left: x, top: y, right: x + w, bottom: y + h };
      var bad = false;
      for (var k = 0; k < obstacles.length; k++) {
        if (rectsOverlap(rect, obstacles[k])) { bad = true; break; }
      }
      if (bad) continue;
      if (avoidPointer && pointer.known &&
          Math.hypot(x + w / 2 - pointer.x, y + h / 2 - pointer.y) < 120) continue;
      return { x: x, y: y };
    }
    return null;
  }

  function applyNo(x, y) {
    noPos.x = x;
    noPos.y = y;
    noBtn.style.left = Math.round(x) + 'px';
    noBtn.style.top = Math.round(y) + 'px';
  }

  function startFleeing() {
    var r = noBtn.getBoundingClientRect();
    // Espaço reservado para o "Sim" não mudar de lugar
    slot = document.createElement('span');
    slot.className = 'slot';
    slot.style.width = r.width + 'px';
    slot.style.height = r.height + 'px';
    buttons.insertBefore(slot, noBtn);

    noBtn.classList.add('is-fleeing');
    noBtn.style.left = r.left + 'px';
    noBtn.style.top = r.top + 'px';
    noPos.x = r.left;
    noPos.y = r.top;
    void noBtn.offsetWidth; // fixa a posição inicial antes de animar
    fled = true;
  }

  function moveNo() {
    if (!fled) startFleeing();

    var w = noBtn.offsetWidth;
    var h = noBtn.offsetHeight;
    var yesR = yesFutureRect();
    var textR = inflate(copy.getBoundingClientRect(), 6);

    var spot =
      findSpot(w, h, [yesR, textR], true) ||
      findSpot(w, h, [yesR], true) ||
      findSpot(w, h, [yesR], false);

    if (!spot) {
      var b = getBounds(w, h);
      var corners = [
        { x: b.minX, y: b.minY }, { x: b.maxX, y: b.minY },
        { x: b.minX, y: b.maxY }, { x: b.maxX, y: b.maxY }
      ];
      spot = corners[0];
      for (var i = 0; i < corners.length; i++) {
        var c = corners[i];
        var rect = { left: c.x, top: c.y, right: c.x + w, bottom: c.y + h };
        if (!rectsOverlap(rect, yesR)) { spot = c; break; }
      }
    }
    applyNo(spot.x, spot.y);
  }

  function growYes() {
    yesScale = Math.min(1.3, yesScale + 0.04);
    yesBtn.style.setProperty('--sim-scale', yesScale.toFixed(2));
  }

  function flee() {
    if (accepted) return;
    var now = Date.now();
    if (now - lastFlee < 150) return;
    lastFlee = now;
    showPhrase();
    growYes();
    moveNo();
  }

  // Garante que o "Não" continue visível e sem tapar o "Sim" (resize, rotação, rolagem)
  function ensureNoValid() {
    if (!fled || accepted) return;
    var w = noBtn.offsetWidth;
    var h = noBtn.offsetHeight;
    var b = getBounds(w, h);
    var out = noPos.x < b.minX - 1 || noPos.x > b.maxX + 1 || noPos.y < b.minY - 1 || noPos.y > b.maxY + 1;
    var rect = { left: noPos.x, top: noPos.y, right: noPos.x + w, bottom: noPos.y + h };
    if (out || rectsOverlap(rect, yesFutureRect())) moveNo();
  }

  var checkTimer = null;
  function scheduleCheck() {
    clearTimeout(checkTimer);
    checkTimer = setTimeout(ensureNoValid, 120);
  }
  window.addEventListener('resize', scheduleCheck);
  window.addEventListener('orientationchange', scheduleCheck);
  window.addEventListener('scroll', scheduleCheck, { passive: true });

  /* ---------- Eventos do "Não" ---------- */
  function setPointer(e) {
    pointer.x = e.clientX;
    pointer.y = e.clientY;
    pointer.known = true;
  }

  document.addEventListener('pointerdown', setPointer, true);

  document.addEventListener('pointermove', function (e) {
    setPointer(e);
    if (accepted || e.pointerType !== 'mouse') return;
    // Computador: foge quando o mouse chega perto
    var r = noBtn.getBoundingClientRect();
    var dx = Math.max(r.left - e.clientX, 0, e.clientX - r.right);
    var dy = Math.max(r.top - e.clientY, 0, e.clientY - r.bottom);
    if (Math.hypot(dx, dy) < 80) flee();
  }, { passive: true });

  noBtn.addEventListener('pointerenter', function (e) {
    if (e.pointerType === 'mouse') flee();
  });

  // Celular: foge no instante em que o dedo encosta (e cancela o clique)
  noBtn.addEventListener('touchstart', function (e) {
    e.preventDefault();
    flee();
  }, { passive: false });

  noBtn.addEventListener('pointerdown', function () { flee(); });
  noBtn.addEventListener('focus', function () { flee(); });

  // Se mesmo assim o clique acontecer (teclado, por exemplo), não faz nada além de fugir
  noBtn.addEventListener('click', function (e) {
    e.preventDefault();
    flee();
  });

  /* ---------- Confetes, corações e brilhos ---------- */
  var ctx = null;
  var particles = [];
  var rafId = null;
  var dpr = 1;
  var lastT = 0;
  var startT = 0;

  function resizeCanvas() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(window.innerWidth * dpr);
    canvas.height = Math.round(window.innerHeight * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spawn(x, y, angle, speed, kind) {
    particles.push({
      x: x, y: y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      size: kind === 'rect' ? rand(7, 12) : rand(10, 20),
      rot: rand(0, Math.PI * 2),
      vr: rand(-0.2, 0.2),
      color: CONFIG.confettiColors[Math.floor(Math.random() * CONFIG.confettiColors.length)],
      kind: kind,
      life: rand(110, 200),
      age: 0
    });
  }

  function pickKind() {
    var r = Math.random();
    return r < 0.4 ? 'rect' : r < 0.75 ? 'heart' : 'spark';
  }

  function burst(n) {
    var w = window.innerWidth;
    var h = window.innerHeight;
    for (var i = 0; i < n; i++) {
      var left = i % 2 === 0;
      var ox = left ? w * 0.08 : w * 0.92;
      var base = left ? -60 : -120;
      var ang = (base + rand(-22, 22)) * Math.PI / 180;
      spawn(ox, h * 0.9, ang, rand(9, 19), pickKind());
    }
  }

  function rain(n) {
    var w = window.innerWidth;
    for (var i = 0; i < n; i++) {
      spawn(rand(0, w), rand(-60, -10), Math.PI / 2 + rand(-0.4, 0.4), rand(1.5, 4.5), pickKind());
    }
  }

  function drawHeart(s) {
    ctx.beginPath();
    ctx.moveTo(0, 0.5 * s);
    ctx.bezierCurveTo(0.9 * s, -0.1 * s, 0.5 * s, -0.7 * s, 0, -0.25 * s);
    ctx.bezierCurveTo(-0.5 * s, -0.7 * s, -0.9 * s, -0.1 * s, 0, 0.5 * s);
    ctx.fill();
  }

  function drawSpark(s) {
    ctx.beginPath();
    ctx.moveTo(0, -s);
    ctx.quadraticCurveTo(0, 0, s, 0);
    ctx.quadraticCurveTo(0, 0, 0, s);
    ctx.quadraticCurveTo(0, 0, -s, 0);
    ctx.quadraticCurveTo(0, 0, 0, -s);
    ctx.fill();
  }

  function frame(t) {
    var dt = Math.min((t - lastT) / 16.67, 3);
    lastT = t;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

    for (var i = particles.length - 1; i >= 0; i--) {
      var p = particles[i];
      p.age += dt;
      p.vy += 0.22 * dt;
      p.vx *= Math.pow(0.992, dt);
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;

      if (p.age > p.life || p.y > window.innerHeight + 40) {
        particles.splice(i, 1);
        continue;
      }

      var remaining = p.life - p.age;
      ctx.globalAlpha = remaining < 30 ? Math.max(remaining / 30, 0) : 1;
      ctx.fillStyle = p.color;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.kind === 'heart' ? p.rot * 0.15 : p.rot);
      if (p.kind === 'rect') ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.6);
      else if (p.kind === 'heart') drawHeart(p.size);
      else drawSpark(p.size * 0.7);
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    if (particles.length > 0 || t - startT < 1800) {
      rafId = requestAnimationFrame(frame);
    } else {
      canvas.hidden = true;
      rafId = null;
    }
  }

  function celebrate() {
    ctx = ctx || canvas.getContext('2d');
    if (!ctx) return;
    canvas.hidden = false;
    resizeCanvas();
    var k = reduceMotion ? 0.35 : 1;

    burst(Math.round(70 * k));
    rain(Math.round(30 * k));
    setTimeout(function () { burst(Math.round(50 * k)); rain(Math.round(30 * k)); }, 650);
    setTimeout(function () { rain(Math.round(40 * k)); }, 1300);

    startT = performance.now();
    lastT = startT;
    if (!rafId) rafId = requestAnimationFrame(frame);
  }

  window.addEventListener('resize', function () { if (ctx && !canvas.hidden) resizeCanvas(); });

  /* ---------- Clique no "SIM" ---------- */
  yesBtn.addEventListener('click', function () {
    if (accepted) return;
    accepted = true;
    clearTimeout(toastTimer);
    toast.classList.remove('show');
    celebrate();
    question.classList.add('leaving');
    setTimeout(function () {
      question.hidden = true;
      success.hidden = false;
    }, 350);
  });

  /* ---------- Botão "Agora combina comigo" ---------- */
  (function setupPlan() {
    var number = String(CONFIG.whatsappNumber || '').replace(/\D/g, '');
    if (number) {
      planBtn.href = 'https://wa.me/' + number + '?text=' + encodeURIComponent(CONFIG.whatsappMessage);
      planBtn.target = '_blank';
      planBtn.rel = 'noopener';
    } else {
      planBtn.addEventListener('click', function (e) {
        e.preventDefault();
        planNote.textContent = CONFIG.noNumberNote;
        planNote.hidden = false;
        celebrate();
      });
    }
  })();
})();
